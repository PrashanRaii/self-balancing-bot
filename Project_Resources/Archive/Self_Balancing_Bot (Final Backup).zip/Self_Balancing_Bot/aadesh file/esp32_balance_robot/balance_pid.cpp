#include <Arduino.h>
#include "balance_pid.h"
#include "motor_control.h"
#include "config.h"

// ---- module-private PID state ----
static float pidError = 0.0f;
static float pidIntegral = 0.0f;
static float pidDerivative = 0.0f;
static unsigned long lastPIDTime = 0;

void initBalancePID()
{
    lastPIDTime = micros();
}

float calculateBalancePID()
{
    unsigned long now = micros();
    float dt = (now - lastPIDTime) / 1000000.0f;
    lastPIDTime = now;

    if (dt <= 0.0f || dt > 0.03f) dt = 0.005f;

    // Positive angle = forward tilt, negative = backward tilt.
    // This error definition is symmetric, so both tilt directions
    // are corrected the same way -- as long as ANGLE_SIGN matches
    // your physical mounting.
    pidError = filteredAngle - balanceSetpoint;

    pidIntegral += pidError * dt;
    pidIntegral = constrain(pidIntegral, -50.0f, 50.0f);

    // Derivative on measurement: use the gyro rate directly instead
    // of differentiating the filtered angle again. This is the
    // standard fix for D-term noise/jitter and removes an entire
    // dt-division from the hot path.
    pidDerivative = gyroRate;

    pidProportional = Kp * pidError;
    pidIntegralOutput = Ki * pidIntegral;
    pidDerivativeOutput = Kd * pidDerivative;
    pidOutput = pidProportional + pidIntegralOutput + pidDerivativeOutput;
    pidOutput = constrain(pidOutput, -PID_LIMIT, PID_LIMIT);

    return pidOutput;
}

void controlMotors()
{
    if (!systemEnabled)
    {
        pidOutput = 0.0f;
        pidProportional = 0.0f;
        pidIntegralOutput = 0.0f;
        pidDerivativeOutput = 0.0f;
        stopMotors();
        return;
    }

    // Stop if MPU has failed to respond for several consecutive
    // reads -- a single glitch shouldn't kill balancing, but a
    // sustained I2C fault must not leave motors running blind.
    if (!mpuOK || mpuFailStreak > 5)
    {
        pidOutput = 0.0f;
        pidProportional = 0.0f;
        pidIntegralOutput = 0.0f;
        pidDerivativeOutput = 0.0f;
        stopMotors();
        return;
    }

    if (fabsf(filteredAngle - balanceSetpoint) > 35.0f)
    {
        pidOutput = 0.0f;
        pidProportional = 0.0f;
        pidIntegralOutput = 0.0f;
        pidDerivativeOutput = 0.0f;
        stopMotors();
        pidIntegral = 0.0f;
        return;
    }

    float balanceOutput = calculateBalancePID();
    balanceOutput *= MOTOR_DIRECTION_SIGN;

    if (!motorsStarted)
    {
        motorsStarted = true;
        motorStartTime = millis();
    }

    unsigned long elapsed = millis() - motorStartTime;
    float startupFactor = (float)elapsed / (float)START_RAMP_TIME;
    startupFactor = constrain(startupFactor, 0.0f, 1.0f);

    float leftCommand  = balanceOutput;
    float rightCommand = balanceOutput;

    float syncCorrection = calculateSyncCorrection();

    if (fabsf(balanceOutput) > 2.0f)
    {
        if (balanceOutput > 0.0f)
        {
            leftCommand  = balanceOutput - syncCorrection;
            rightCommand = balanceOutput + syncCorrection;
        }
        else
        {
            leftCommand  = balanceOutput + syncCorrection;
            rightCommand = balanceOutput - syncCorrection;
        }
    }

    // Trim boosts whichever wheel is the slower one. Applied as a
    // flat addition, it would help the slow wheel going forward but
    // *hurt* it going backward -- and balanceOutput's sign flips
    // constantly as a balancing robot leans forward and back around
    // vertical. Scale by the direction we're actually driving so it
    // always pushes the slow wheel's magnitude up, either way.
    float trimSign = (balanceOutput >= 0.0f) ? 1.0f : -1.0f;
    leftCommand  += trimSign * leftMotorTrim;
    rightCommand += trimSign * rightMotorTrim;

    leftCommand  *= startupFactor;
    rightCommand *= startupFactor;

    leftCommand  = slewLeftCommand(leftCommand);
    rightCommand = slewRightCommand(rightCommand);

    applyLeftMotor(leftCommand);
    applyRightMotor(rightCommand);

    static unsigned long lastTrimUpdate = 0;
    if (millis() - lastTrimUpdate >= 100)
    {
        lastTrimUpdate = millis();
        updateMotorTrim();
    }
}
