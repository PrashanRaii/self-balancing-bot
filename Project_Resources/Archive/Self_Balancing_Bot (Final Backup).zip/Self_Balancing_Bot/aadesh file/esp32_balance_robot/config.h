#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// ============================================================
// COMPILE-TIME CONFIGURATION
// Wiring, hardware constants, and fixed tuning limits.
// Edit these to match YOUR wiring / hardware.
// ============================================================

// ---------------- MPU6050 ----------------
#define MPU_ADDR 0x68
#define MPU_SDA  21
#define MPU_SCL  22

// ---------------- LEFT MOTOR DRIVER ----------------
#define LEFT_ENA 25
#define LEFT_IN1 26
#define LEFT_IN2 27

// ---------------- RIGHT MOTOR DRIVER ----------------
#define RIGHT_ENA 14
#define RIGHT_IN3 4
#define RIGHT_IN4 5

// ---------------- LEFT / RIGHT ENCODER ----------------
#define LEFT_C1  18
#define LEFT_C2  19
#define RIGHT_C1 23
#define RIGHT_C2 13

// ---------------- MOTOR DIRECTION ----------------
// LEFT = normal, RIGHT = electrically reversed (mirror mounting)
// so BOTH PHYSICAL WHEELS rotate the SAME physical direction.
const bool LEFT_REVERSE  = false;
const bool RIGHT_REVERSE = true;

// If the whole robot drives backward when it should drive
// forward (wheels correct relative to each other, just the
// overall sense flipped), set this to -1.
const float MOTOR_DIRECTION_SIGN = 1.0f;

// If forward/backward tilt recovery is asymmetric (robot fights
// harder recovering one way than the other), your MPU is mounted
// with an inverted axis. Flip this to -1.
const float ANGLE_SIGN = 1.0f;

// Encoder counts per one output-shaft (wheel) revolution, after
// x4 quadrature decoding. Measured directly on this robot (same
// value on both wheels, as expected for a matched gearbox pair).
const float COUNTS_PER_REV = 1215.0f;

// ---------------- WIFI ----------------
const char* const WIFI_SSID     = "BalanceRobot";
const char* const WIFI_PASSWORD = "12345678";

// ---------------- BALANCE PID LIMITS ----------------
const float PID_LIMIT = 255.0f;

// ---------------- RPM SYNCHRONIZATION ----------------
const float MAX_SYNC_CORRECTION = 35.0f;
const float RPM_FILTER_ALPHA    = 0.4f;   // smoothing for RPM used in sync

// ---------------- AUTOMATIC MOTOR TRIM ----------------
const float MAX_MOTOR_TRIM     = 25.0f;
const float TRIM_LEARNING_RATE = 0.015f;

// ---------------- MOTOR START RAMP ----------------
const unsigned long START_RAMP_TIME = 180;

// ---------------- PWM SLEW LIMIT ----------------
const float MAX_PWM_CHANGE = 20.0f;


// ============================================================
// SHARED RUNTIME STATE
// Defined once in the main .ino; every module reads/writes
// these through this header. Grouped by which module owns the
// *writing* of each value.
// ============================================================

// ---- web-tunable PID / filter parameters ----
extern float Kp, Ki, Kd;
extern float balanceSetpoint;
extern float filterAlpha;
extern float syncGain;
extern int   leftMinPWM, rightMinPWM;
extern bool  systemEnabled;

// ---- MPU / angle estimate (written by mpu_sensor) ----
extern float accelAngle;
extern float gyroRate;
extern float filteredAngle;
extern bool  mpuOK;
extern uint8_t mpuFailStreak;

// Motor output status, used by the MPU stationary-calibration guard.
extern int leftPWM, rightPWM;

// ---- encoders (written by motor_control ISRs) ----
extern volatile long leftEncoderCount;
extern volatile long rightEncoderCount;

// ---- RPM, filtered (written by motor_control) ----
extern float leftRPMFiltered;
extern float rightRPMFiltered;
extern float rpmDifference;

// ---- automatic motor trim (written by motor_control) ----
extern float leftMotorTrim;
extern float rightMotorTrim;

// ---- motor output status (written by motor_control) ----
extern int    leftPWM, rightPWM;
extern String leftDirection, rightDirection;

// ---- balance PID output, for telemetry (written by balance_pid) ----
extern float pidOutput;
extern float pidProportional;
extern float pidIntegralOutput;
extern float pidDerivativeOutput;

// ---- startup ramp (shared between balance_pid and motor_control) ----
extern bool motorsStarted;
extern unsigned long motorStartTime;

#endif
