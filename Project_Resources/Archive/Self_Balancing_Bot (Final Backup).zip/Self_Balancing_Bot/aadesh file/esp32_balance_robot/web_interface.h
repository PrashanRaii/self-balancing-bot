#ifndef WEB_INTERFACE_H
#define WEB_INTERFACE_H

// Starts the WiFi access point, HTTP server, and web task (dashboard +
// /data + /setPID endpoints). Call once from setup().
void initWebInterface();

#endif
